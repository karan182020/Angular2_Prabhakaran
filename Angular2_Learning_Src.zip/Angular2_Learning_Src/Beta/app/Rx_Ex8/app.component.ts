import {Component} from 'angular2/core';
import {ControlGroup, FormBuilder} from 'angular2/common'; 

import {Observable} from 'rxjs/Observable';
import 'rxjs/add/observable/from';

@Component({
    selector: 'my-app',    
    template: `
       <form [ngFormModel]="form1">
            <input type="text" ngControl="search1" >
       </form>
    `,  
    
})
export class AppComponent {

    form1 : ControlGroup;

    constructor(fb : FormBuilder){
        this.form1 = fb.group({
            search1 : []
        });

        var search = this.form1.find('search1');
        search.valueChanges
              //.debounceTime(400)
              //.map( str => ( <string>str ).replace(' ','-') )
              .subscribe( x => console.log(x));

        var observable = Observable.from([1,2,3]);

        var startDates = [];
        var startDate = new Date(); //today

        for (var day = -2; day <= 2; day++ ){
            var date = new Date(
                 startDate.getFullYear(),
                 startDate.getMonth(),
                 startDate.getDate() + day);
            startDates.push(date);
        }

        Observable.from(startDates);

        // Observable.from(startDates)
        //           .map( date1 => console.log("Getting deals for date " + date1))
        //           .subscribe( x => console.log(x));

    }

    

  
}