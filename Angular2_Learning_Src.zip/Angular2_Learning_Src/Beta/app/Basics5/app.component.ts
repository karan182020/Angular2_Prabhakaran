import {Component} from 'angular2/core';
import {BootstrapPanel} from './bootstrap.panel.component'

@Component({
    selector: 'my-app',  
   /* template: `
            <button
                [ngStyle]="{
                    backgroundColor : canSave ? 'blue' : 'grey',
                    color : canSave ? 'white' : 'black',
                    fontWeight : canSave ? 'bold' : 'normal'
                }"                
            >Submit</button>
        `   */   
     /*   template : `
            <ul>
                <li>Title : {{ task.title }}</li>
                <li>Assigned to: {{ task.assignee?.name }}</li>
            </ul>
        `*/
        template: `
            <bs-panel>
                <div class="heading">The Heading</div>
                <div class="body">This is the body.</div>
                <div class="body">This is another body.</div>
            </bs-panel>
        `,
        directives: [BootstrapPanel]
}) 
export class AppComponent { 
    //canSave = true;   
    /*task = {
        title : "Review applications",
        assignee : null
    }*/

}