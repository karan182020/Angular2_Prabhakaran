System.register(['angular2/core', './Ex1/courses.component', './authors.component'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, courses_component_1, authors_component_1;
    var AppComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (courses_component_1_1) {
                courses_component_1 = courses_component_1_1;
            },
            function (authors_component_1_1) {
                authors_component_1 = authors_component_1_1;
            }],
        execute: function() {
            AppComponent = (function () {
                function AppComponent() {
                    this.isActive1 = false;
                    this.title1 = "Angular 2";
                }
                AppComponent.prototype.OnDivClick1 = function () {
                    console.log("Div Click");
                };
                // Event Handler.
                AppComponent.prototype.OnClick1 = function ($event) {
                    $event.stopPropagation(); // to stop Event bubbling
                    console.log("Clicked", $event);
                };
                // (input) event gets called when user types the text. 
                // This method was created for text box.
                AppComponent.prototype.updateInput = function ($event) {
                    this.title1 = $event.target.value;
                };
                AppComponent = __decorate([
                    core_1.Component({
                        selector: 'my-app',
                        template: "\n        <h1>Vanakkam tamizhnadu</h1>\n        <courses></courses>\n        <authors></authors>\n        <button class=\"btn btn-primary\" [class.active]=\"isActive1\"\n        [style.backgroundColor]=\"isActive1 ? 'blue' : 'red' \">Submit</button>\n        <div (click)=\"OnDivClick1()\">\n            <button (click)=\"OnClick1($event)\">Click Me</button>\n        </div>\n        \n        <input type=\"text\" [(ngModel)]=\"title1\" />\n        Preview : {{ title1 }}\n        <input type=\"button\" (click)=\"title1 = '' \" value=\"Clear\" />\n        ",
                        directives: [courses_component_1.CoursesComponent, authors_component_1.AuthorComponent]
                    }), 
                    __metadata('design:paramtypes', [])
                ], AppComponent);
                return AppComponent;
            }());
            exports_1("AppComponent", AppComponent);
        }
    }
});
//# sourceMappingURL=app.component.js.map