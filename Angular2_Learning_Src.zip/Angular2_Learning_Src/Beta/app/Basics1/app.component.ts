import {Component} from 'angular2/core';
import {CoursesComponent} from './Ex1/courses.component'
import {AuthorComponent} from './authors.component'

@Component({
    selector: 'my-app',
    template: `
        <h1>Vanakkam tamizhnadu</h1>
        <courses></courses>
        <authors></authors>
        <button class="btn btn-primary" [class.active]="isActive1"
        [style.backgroundColor]="isActive1 ? 'blue' : 'red' ">Submit</button>
        <div (click)="OnDivClick1()">
            <button (click)="OnClick1($event)">Click Me</button>
        </div>
        
        <input type="text" [(ngModel)]="title1" />
        Preview : {{ title1 }}
        <input type="button" (click)="title1 = '' " value="Clear" />
        `,
    directives: [CoursesComponent,AuthorComponent]
}) // btn, btn-primary, active are classes.
export class AppComponent { 
    isActive1 = false;
    title1 = "Angular 2"

    OnDivClick1(){
        console.log("Div Click");
    }

    // Event Handler.
    OnClick1($event){
        $event.stopPropagation(); // to stop Event bubbling
        console.log("Clicked",$event);
    }

    // (input) event gets called when user types the text. 
    // This method was created for text box.
    updateInput($event){
        this.title1 = $event.target.value;
    }
}