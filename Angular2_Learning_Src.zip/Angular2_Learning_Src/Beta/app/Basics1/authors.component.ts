import {Component} from 'angular2/core'
import {AuthorService} from './author.service'

@Component({
    selector:'authors',
    template:`
        <h2>Authors</h2>
        {{ title1 }}
        <ul>
            <li *ngFor="#author of authors1">
                {{ author }}
            </li>
        </ul>
    `,
    providers: [AuthorService]
})
export class AuthorComponent{
    title1 = "Title for the authors page";
    authors1;

    constructor(authorService1: AuthorService){
        this.authors1 = authorService1.getAuthors();
    }
}