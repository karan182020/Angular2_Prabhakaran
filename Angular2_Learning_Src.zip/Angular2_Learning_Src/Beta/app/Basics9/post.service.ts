import {Http} from 'angular2/http';
import 'rxjs/add/operator/map';
import {Injectable} from 'angular2/core';
import {Post} from './Post'
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class PostService{
    private _url = "https://jsonplaceholder.typicode.com/posts";

    constructor(private _http : Http){

    }

    getPosts() : Observable<Post[]>{
        var response = this._http.get(this._url);
        return response.map(res1 => res1.json())
    }

    // If you want to use Promise method.
/*     getPosts() : Promise<Post[]>{
        var response = this._http.get(this._url);
        return response.map(res1 => res1.json())
                       .toPromise();
    }*/

    createPost(post : Post){
        return this._http.post(this._url, JSON.stringify(post))
                .map( res1 => res1.json());
    }
}