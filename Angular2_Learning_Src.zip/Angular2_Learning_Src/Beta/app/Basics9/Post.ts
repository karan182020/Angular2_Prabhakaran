
export interface Post{
    userId : number;
    id?: number; // optional property.
    title : string;
    body : string;
}