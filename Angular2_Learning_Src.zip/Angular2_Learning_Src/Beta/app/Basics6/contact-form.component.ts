import {Component} from 'angular2/core';



@Component({
    selector: 'contact-form', 
    templateUrl: `app/contact-form.component.html`      
}) 
export class ContactFormComponent { 
  
/*    log(x){
        console.log(x);
    }*/

    // We can call a method on the Server to save the data. 
    onSubmit(form){
        console.log(form);
    }
}