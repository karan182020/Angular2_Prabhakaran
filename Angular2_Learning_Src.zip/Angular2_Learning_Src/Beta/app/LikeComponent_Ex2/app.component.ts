import {Component} from 'angular2/core';
import {LikeComponent} from './like.component'



@Component({
    selector: 'my-app',
    template: `
          <like [totalLikes]="tweet.totalLikes2" [iLike]="tweet.iLike2">
          </like>
        `,
    directives: [LikeComponent]    
}) 
export class AppComponent { 
    // Tweets will be received from server.   
    tweet = {
        totalLikes2 : 10,
        iLike2 : false
    }    

}