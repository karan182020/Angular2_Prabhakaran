import {Component} from 'angular2/core';


@Component({
    selector: 'my-app',
/*    template: `
        <div *ngIf="courses.length > 0">
            List of Courses
        </div>

         <div *ngIf="courses.length == 0">
            No Courses yet. 
        </div>
    `*/
 /*       template: `
        <div [hidden]="courses.length == 0">
            List of Courses
        </div>

         <div [hidden]="courses.length > 0">
            No Courses yet. 
        </div>
    `*/
 /*       template: `
            <ul class="nav nav-pills">
                <li [class.active]="viewMode == 'map'">
                    <a (click)="viewMode = 'map' ">Map View</a>
                </li>
                <li [class.active]="viewMode == 'list'">
                    <a (click)="viewMode = 'list' ">List View</a>
                </li>
            </ul>

            <div [ngSwitch]="viewMode">
                <template [ngSwitchWhen]="'map'" ngSwitchDefault>Map View Content</template>
                <template [ngSwitchWhen]="'list'">List View Content</template>
            </div>
        `*/
        template : `
            <ul>
                <li *ngFor="#course of courses, #i1 = index">
                    {{ i1 + 1 }} - {{ course }}
                </li>
            </ul>
        `
}) 
export class AppComponent { 
    
    //courses = [];
    //viewMode = 'map';

    courses = ['Course1', 'Course2', 'Course3'];
   
}