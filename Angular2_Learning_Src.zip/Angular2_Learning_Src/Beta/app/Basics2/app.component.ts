import {Component} from 'angular2/core';
import {FavoriteComponent} from './favorite.component'


@Component({
    selector: 'my-app',
    template: `
            <i class="glyphicon glyphicon-star"></i>
            <favorite [is-Clicked]="post.isFavorite3"
                      (change1)="OnFavoriteChange($event)" ></favorite>
        `,
    directives: [FavoriteComponent]
}) 
export class AppComponent {
    post={
        title2: "Title2",
        isFavorite3: true
    }

    OnFavoriteChange($event){
        console.log($event);
    }

    
 
}