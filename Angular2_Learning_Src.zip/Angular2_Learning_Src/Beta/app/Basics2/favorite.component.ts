import {Component, Input, Output, EventEmitter} from 'angular2/core'

@Component({
    selector: 'favorite',
    templateUrl: 'app/favorite.template.html',
    styles: [`
        .glyphicon-star{
            color: orange;
        }
        `]
    
})
export class FavoriteComponent{

     @Input("is-Clicked") isClicked = false; 

     @Output() change1 = new EventEmitter();

    onClick1(){
        console.log("Clicked Star");
        this.isClicked = !this.isClicked;
        this.change1.emit({ newValue1: this.isClicked });
    }

}