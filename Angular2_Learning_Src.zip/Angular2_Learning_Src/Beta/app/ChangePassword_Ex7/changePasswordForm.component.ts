import {Component} from 'angular2/core';
import {ControlGroup, Validators, FormBuilder} from 'angular2/common'
import {PasswordValidators} from './PasswordValidators';


@Component({
    selector: 'change-password',    
    templateUrl: `app/changePasswordForm.component.html`
})
export class ChangePasswordComponent {

    form : ControlGroup;

    constructor(fb : FormBuilder){
        this.form = fb.group({
            oldPassword : ['', Validators.compose([
                                Validators.required                                
                                ])],
            newPassword : ['',Validators.compose([
                            Validators.required,                            
                            PasswordValidators.complexPassword
                                ])],
            confirmPassword : ['',Validators.compose([
                            Validators.required                                                      
                                ])]
        }, { validator : PasswordValidators.passwordsShouldMatch });
    }

    changePassword(){
        
        var currentPw = this.form.find('oldPassword');
        if (currentPw.value != '1234'){
                currentPw.setErrors({ validOldPassword : true });
        }

        if(this.form.valid)
            alert("Password successfully changed");


    }

}