System.register(['angular2/core', 'angular2/common', './PasswordValidators'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, PasswordValidators_1;
    var ChangePasswordComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (PasswordValidators_1_1) {
                PasswordValidators_1 = PasswordValidators_1_1;
            }],
        execute: function() {
            ChangePasswordComponent = (function () {
                function ChangePasswordComponent(fb) {
                    this.form = fb.group({
                        oldPassword: ['', common_1.Validators.compose([
                                common_1.Validators.required
                            ])],
                        newPassword: ['', common_1.Validators.compose([
                                common_1.Validators.required,
                                PasswordValidators_1.PasswordValidators.complexPassword
                            ])],
                        confirmPassword: ['', common_1.Validators.compose([
                                common_1.Validators.required
                            ])]
                    }, { validator: PasswordValidators_1.PasswordValidators.passwordsShouldMatch });
                }
                ChangePasswordComponent.prototype.changePassword = function () {
                    var currentPw = this.form.find('oldPassword');
                    if (currentPw.value != '1234') {
                        currentPw.setErrors({ validOldPassword: true });
                    }
                    if (this.form.valid)
                        alert("Password successfully changed");
                };
                ChangePasswordComponent = __decorate([
                    core_1.Component({
                        selector: 'change-password',
                        templateUrl: "app/changePasswordForm.component.html"
                    }), 
                    __metadata('design:paramtypes', [common_1.FormBuilder])
                ], ChangePasswordComponent);
                return ChangePasswordComponent;
            }());
            exports_1("ChangePasswordComponent", ChangePasswordComponent);
        }
    }
});
//# sourceMappingURL=changePasswordForm.component.js.map