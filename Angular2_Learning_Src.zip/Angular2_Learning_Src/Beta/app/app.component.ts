import {Component} from 'angular2/core';

@Component({
    selector: 'my-app',
    template: ''
})
export class AppComponent {
}