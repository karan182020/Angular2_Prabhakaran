import {Component} from 'angular2/core';
import {VoterComponent} from './vote.component'



@Component({
    selector: 'my-app',
    template: `
          <voter 
            [voteCount]="votes.voteCount1"
            [myVote]="votes.myVote2"
            (vote)="onVote($event)" >
        </voter>
        `,
    directives: [VoterComponent]    
}) 
export class AppComponent { 
    // Tweets will be received from server.   
    votes = {
        voteCount1 : 10,
        myVote2 : 0    
    }   

    onVote($event) {
        console.log($event);
    }

}