import {Component} from 'angular2/core';


@Component({
    selector: 'contact-form1', 
    templateUrl: `app/contact-form1.component.html`        
}) 
export class ContactForm1Component { 
    frequencies = [
        { id: 1, label: 'Daily'},
        { id: 2, label: 'Weekly'},
        { id: 3, label: 'Monthly'},
    ];

    onSubscribe(form){
        console.log(form);        
    }
  
}