import {Component} from 'angular2/core'

@Component({
    selector: 'favorite',
   /* template: 
    `  
        <i class="glyphicon"
           [class.glyphicon-star-empty] = "!isClicked"
           [class.glyphicon-star] = "isClicked"
            (click)="onClick1()">
        </i>
    ` */   
     template: 
    `  
        <i class="glyphicon"
           [ngClass]="{
                'glyphicon-star-empty' : !isClicked,
                 'glyphicon-star' : isClicked
           }"
            (click)="onClick1()">
        </i>
    `
})
export class FavoriteComponent{

     isClicked = false; 

    onClick1(){
        console.log("Clicked Star");
        this.isClicked = !this.isClicked;
    }

}