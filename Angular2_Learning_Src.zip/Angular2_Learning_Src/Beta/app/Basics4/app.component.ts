import {Component} from 'angular2/core';
import {SummaryPipe} from './summary.pipe';


@Component({
    selector: 'my-app',
   /* template : `
            {{ course.title | uppercase }}
            <br/>
            {{ course.students | number }}
            <br/>
            {{ course.rating | number:'2.2-2' }}
            <br/>
            {{ course.price | currency:'INR':true:'2.2-2' }}
            <br/>
            {{ course.releaseDate | date:'MMM yyyy' }}
            <br/>
            {{ course | json }}
        `*/
        template: `
            {{ post.title }}
            <br/>
            {{ post.body | summary:20 }}
        `,
        pipes : [SummaryPipe]
        
}) 
export class AppComponent { 
   /* course = {
        title : "Angular 2",
        students : 1234,
        rating : 4.9745,
        price : 99.95,
        releaseDate : new Date(2017, 3, 18)
    }  */  

    post = {
        title : "Angular tutorial for Beginners",
        body : `
            Learning Angular 2 to develop web application. Angular 2 is used with
            Spring Boot and SQL. Project is related to Medical and Hospitals. It will be 
            useful for common people at emergency time.
        `
    }

   
}