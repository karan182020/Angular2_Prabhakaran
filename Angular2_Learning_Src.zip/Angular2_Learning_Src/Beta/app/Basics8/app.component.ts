import {Component} from 'angular2/core';
import {Observable} from 'rxjs/Rx'

// To improve Performance, we can import specific operators.
// import {Observable} from 'rxjs/Observable';
// import 'rxjs/add/operator/map';
// import 'rxjs/add/operator/filter';
// import 'rxjs/add/operator/debounceTime';
// import 'rxjs/add/operator/distinctUntilChanged';
// import 'rxjs/add/operator/flatMap';

@Component({
    selector: 'my-app',    
    template: `
        <input id="search" type="text" class="form-control" placeholder="Search...">
    `,  
    
})
export class AppComponent {

    //constructor(){
    ngOnInit(){
        // map - transfrom DOM element into value.
        // distinctUntilChanged - to avoid triggering event when using left and right arrow keys.
        // flatMap - transfrom Observable into data elements. E.g. JSON data here.
        // Search code can be put into one method defined in Service
        // e.g. flatMap(spotifyService.searchArtists)
        var keyups = Observable.fromEvent($("#search"),"keyup")
         .map(e => e.target.value) 
         .filter(text => text.length >= 3) 
         .debounceTime(400)
         .distinctUntilChanged()
         .flatMap(searchTerm => {
             var url = "https://api.spotify.com/v1/search?type=artist&q=" + searchTerm;
             // AJAX call
             // We should try to avoid callback methods if possible in Observable.
            //  $.getJSON(url, function(artists){
              //  console.log(artists);
             //});

             var promise = $.getJSON(url); // jQuery
             var observable = Observable.fromPromise(promise);

             return observable;

         }); 
        // event is triggered when key is pressed.
        // and it is placed into Observable and pushed back then we log it.
        var subscription = keyups.subscribe(data => console.log(data));
        // We can use unsubscribe method to implement Notification.
        //subscription.unsubscribe();
    }
}