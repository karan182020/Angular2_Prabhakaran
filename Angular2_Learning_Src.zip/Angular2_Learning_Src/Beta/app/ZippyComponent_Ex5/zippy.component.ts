import {Component, Input} from 'angular2/core';

@Component({
    selector: 'zippy',
    template: `
        <div 
            class="zippy-title"
            (click)="toggle()">
            {{ title1 }}           
            <i 
                class="pull-right glyphicon"
                [ngClass]="
                    {
                        'glyphicon-chevron-down': !isExpanded,
                        'glyphicon-chevron-up': isExpanded
                    }">
            </i>
        </div>

        <div *ngIf="isExpanded" class="zippy-content">
            <ng-content></ng-content>
        </div>
    `
    
})
export class ZippyComponent{
    isExpanded = false;
    @Input() title1 : string;

    toggle(){
        this.isExpanded = !this.isExpanded;
    }
}