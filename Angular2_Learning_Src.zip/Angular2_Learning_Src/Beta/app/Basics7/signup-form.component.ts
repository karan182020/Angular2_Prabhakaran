import {Component} from 'angular2/core';
import {Control, ControlGroup, Validators, FormBuilder} from 'angular2/common';
import {UsernameValidators} from './usernameValidator';

@Component({
    selector: 'signup-form',
    templateUrl: 'app/signup-form.component.html'
})
export class SignUpFormComponent {
/*    form1 = new ControlGroup({
        username1 : new Control('', Validators.required),
        password1 : new Control('', Validators.required)
    });*/

    form1 : ControlGroup;

    constructor(fb: FormBuilder){
        this.form1 = fb.group({
           /* username1 : ['',Validators.required],
            password1 : ['',Validators.required]*/
            username1 : ['',Validators.compose([
                                Validators.required, 
                                UsernameValidators.cannotContainSpace
                            ]), 
                            UsernameValidators.shouldBeUnique],
            password1 : ['',Validators.required]
            
        });
    }

    signUp(){
        // For e.g. var result = authService.login(this.form.value); in Service class.
        // Assume that result value is false. 
        // Below validation is done upon form submit. 
        this.form1.find('username1').setErrors({ // add errors
            inValidLogin : true // inValidLogin can be Custom Validator
        });

        console.log(this.form1.value);
    }
}