import { Component } from '@angular/core';
import { AuthService } from './auth.service';

@Component({
  template: `<h1>Home Page</h1>
  `
})
export class HomeComponent { 

  // In this component, form should be loaded.

    constructor(authService: AuthService){
      authService.login("username","password");
    }
}