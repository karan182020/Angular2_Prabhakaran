import { Injectable } from '@angular/core';

/**
 * AuthService
 */
@Injectable()
export class AuthService {

    isLoggedIn = false;

    login(username, password){
        // Call remote service to authenticate.
        // that will return true or false.
        this.isLoggedIn = true;
    }

    logout(){
        this.isLoggedIn = false;
    }
}